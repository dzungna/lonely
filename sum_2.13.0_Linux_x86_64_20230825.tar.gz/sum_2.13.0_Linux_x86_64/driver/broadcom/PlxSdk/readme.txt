1. Go to "../PlxSdk/Driver" folder.
2. Execute "sudo ./builddriver Svc" to build driver.
3. Go to "../PlxSdk/Bin" folder.
4. Execute "sudo ./Plx_load Svc" to load driver.