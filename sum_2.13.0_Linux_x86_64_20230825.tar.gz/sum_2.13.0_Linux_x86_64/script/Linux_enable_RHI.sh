enable_network_interface() {
    local driver_name=$1
    local SYSTEM=$2
    local RENAME=false
    
    if [[ $SYSTEM == "debian" ]]; then
        INTERFACE=$(dmesg | grep -o $driver_name.*:\ register\ \'$driver_name\' | tail -1 | cut -d ' ' -f3 | sed 's/://')
        MAC_T=$(dmesg | grep -o $driver_name.*:\ register\ \'$driver_name\' | tail -1 | grep -o '[^ ]*$')
        
	if $(dmesg | grep -e "$driver_name.*renamed" -e "register '$driver_name'" | tail -1 | grep -q renamed); then
            INTERFACE_RENAMED=$(dmesg | grep -o "$driver_name.*renamed" | tail -1 | cut -d ' ' -f3 | sed 's/://') 
            RENAME=true    
        fi
    else
        MAC=$(journalctl -k --output cat | grep \'$driver_name\' | tail -n 1)
        MAC_T=$(echo $MAC | rev | cut -d" " -f 1 | rev)
        INTERFACE=$(echo $MAC | awk '{print $3}' | sed 's/://') 
        
        if $(journalctl -k --output cat | grep -e "$driver_name.*renamed" -e "register '$driver_name'" | tail -1 | grep -q renamed) ; then
            INTERFACE_RENAMED=$(journalctl -k --output cat | grep -o "$driver_name.*renamed" | tail -1 | awk '{print $3}' | sed  's/://')
            RENAME=true
        fi
    fi
    
    for i in $(ls /sys/class/net); do
        MAC_C=$(cat /sys/class/net/$i/address)
        if [[ "$MAC_T" == "$MAC_C" ]]; then
            ip link set dev $i up
            ip addr add 169.254.3.1/24 dev $i
            exit 0
        fi
    done

    # Handle the renaming case
    if [[ $RENAME == "true" ]]; then
        ip link set dev $INTERFACE_RENAMED up
        ip addr add 169.254.3.1/24 dev $INTERFACE_RENAMED
        exit 0
    fi

    # If renaming does not occur
    if $(ls /sys/class/net | grep -q $INTERFACE); then
        ip link set dev $INTERFACE up
        ip addr add 169.254.3.1/24 dev $INTERFACE
        exit 0
    fi
   
    echo "RHI enable failed, please report the issue."
    exit 1
}
enable_checking(){
    ping -w 1 -c 1 169.254.3.1 > /dev/null 2>&1
    if [ $? -eq 0 ]; then
        echo "Redfish Host Interface has already been enabled."
    exit 0
    fi
}
environment_checking(){
    # If the debian system
    if $(cat /etc/*-release | grep -q Debian);then
        SYSTEM=debian
    else
        SYSTEM=others
    fi
    
    # Determine the driver name
    if [[ $SYSTEM == "debian" ]]; then
        LASTEST_REGISTER=$(dmesg | grep 'rndis_host\|cdc_subset\|cdc_ether' | tail -1)
    else
        LASTEST_REGISTER=$(journalctl -k --output cat | grep 'rndis_host\|cdc_subset\|cdc_ether'| tail -1)
    fi
     
    if $(echo $LASTEST_REGISTER | grep -q rndis_host); then
        echo "RNDIS host found, enabling the interface."
        name=rndis_host 
    elif $(echo $LASTEST_REGISTER | grep -q cdc_ether); then
        echo "CDC ether found, enabling the interface." 
        name=cdc_ether
    elif $(echo $LASTEST_REGISTER | grep -q cdc_subset); then
        echo "CDC subset found, enabling the interface."
        name=cdc_subset
    else
        echo "Redfish host interface not found, please check the support for the platforms."
        exit 0
    fi
}

enable_checking
environment_checking
enable_network_interface "$name" "$SYSTEM"
